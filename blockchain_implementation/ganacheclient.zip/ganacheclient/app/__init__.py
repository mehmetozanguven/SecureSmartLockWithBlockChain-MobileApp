from flask import Flask

app = Flask(__name__)
app.config.from_mapping(
        DEBUG = False
        )

from app import routes
