from flask import Flask
from flask import jsonify
from flask import request
from app import app

from web3 import Web3
import json

ganacheUrl = "http://10.0.0.5:8545"
web3 = Web3(Web3.HTTPProvider(ganacheUrl))

# connect account 0
web3.eth.defaultAccount = web3.eth.accounts[0]


abi = json.loads('[ { "constant": true, "inputs": [ { "name": "devId", "type": "uint256" } ], "name": "getLogs", "outputs": [ { "name": "", "type": "string" } ], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [ { "name": "devId", "type": "uint256" }, { "name": "log", "type": "string" } ], "name": "addLog", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "inputs": [], "payable": false, "stateMutability": "nonpayable", "type": "constructor" } ]')

# address where we deploy the contract
address = web3.toChecksumAddress("0x62104e429BC3C0F9550E058B1c8a0F79f9E7aa0d")
contract = web3.eth.contract(address=address, abi=abi)
# request body should be {"id": "devId"}
@app.route("/getLogs", methods=['POST'])
def getLogs():
    id = request.get_json()['id']
    id = int(id)
    logs = contract.functions.getLogs(id).call()
    return logs
	
# request body should be {"id": "devId", "log" : "logtoAdd"}
@app.route("/addLog", methods=['POST'])
def addLog():
    params = request.get_json()
    id = params['id']
    id = int(id)
    log = params['log']
    # update the contract with new person
    tx_hash = contract.functions.addLog(id, log).transact()
    # wait until operation is done
    web3.eth.waitForTransactionReceipt(tx_hash)
    return jsonify ({"id" : id, "log" : log})
