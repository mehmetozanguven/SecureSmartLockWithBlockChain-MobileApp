from flask import Flask
from flask import jsonify
from flask import request


from web3 import Web3
import json

ganacheUrl = "http://10.0.0.5:8545"
web3 = Web3(Web3.HTTPProvider(ganacheUrl))

# connect account 0
web3.eth.defaultAccount = web3.eth.accounts[0]


abi = json.loads('[{"constant":false,"inputs":[],"name":"getSuccessAccessNumber","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"successId","type":"uint256"}],"name":"getOneSuccessAccessName","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"unSuccessAccessMap","outputs":[{"name":"_accessName","type":"string"},{"name":"_accessTime","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"successAccessMap","outputs":[{"name":"_accessName","type":"string"},{"name":"_accessTime","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"successId","type":"uint256"}],"name":"getOneSuccessAccessTime","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"unSuccessAccessCount","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"successAccessCount","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"unSuccessId","type":"uint256"}],"name":"getOneUnSuccessAccessTime","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_accessName","type":"string"},{"name":"accessTime","type":"string"}],"name":"addSuccessPerson","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"getUnSuccessAccessNumber","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_accessName","type":"string"},{"name":"accessTime","type":"string"}],"name":"addUnSuccessPerson","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"unSuccessId","type":"uint256"}],"name":"getOneUnSuccessAccessName","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"nonpayable","type":"function"}]')

# address where we deploy the contract
address = web3.toChecksumAddress("0x62104e429bc3c0f9550e058b1c8a0f79f9e7aa0d")


contract = web3.eth.contract(address=address, abi=abi)


app = Flask(__name__)

@app.route("/getAllSuccessAccess", methods=['GET'])
def getAllSuccessAccess():
    lastSuccessNumber = contract.functions.getSuccessAccessNumber().call()
    allList = list()

    if (lastSuccessNumber < 0):
        return jsonify(allList)

    for i in reversed(range(0,lastSuccessNumber)):
        lastAccessPerson = contract.functions.getOneSuccessAccessName(i).call()
        lastAccessTime = contract.functions.getOneSuccessAccessTime(i).call()
        allList.append({'person_name': lastAccessPerson, 'access_time': lastAccessTime})
    return jsonify(allList)

@app.route("/getLastSuccessAccess", methods=['GET'])
def getLastSuccessAccess():
    lastSuccessNumber = contract.functions.getSuccessAccessNumber().call()
    lastSuccessNumber = lastSuccessNumber - 1

    if lastSuccessNumber < 0:
        return jsonify({'person_name': "", 'access_time': ""})

    lastAccessPerson = contract.functions.getOneSuccessAccessName(lastSuccessNumber).call()
    lastAccessTime = contract.functions.getOneSuccessAccessTime(lastSuccessNumber).call()
    return jsonify ({'person_name': lastAccessPerson, 'access_time': lastAccessTime})

# request body should be {"name": "accessName", "time": "accessTime"}
@app.route("/addNewSuccessAccess", methods=['POST'])
def addNewSuccessAccess():
    new_access = request.get_json()
    access_name = new_access['name']
    access_time = new_access['time']
    # update the contract with new person
    tx_hash = contract.functions.addSuccessPerson(access_name, access_time).transact()
    # wait until operation is done
    web3.eth.waitForTransactionReceipt(tx_hash)
    # after operation is done return okey
    return jsonify ({'ok': "okey"})

@app.route('/getAllUnSuccessAccess', methods=['GET'])
def getAllUnSuccessAccess():
    lastUnSuccessNumber = contract.functions.getUnSuccessAccessNumber().call()
    allList = list()

    if (lastUnSuccessNumber < 0):
        return jsonify(allList)

    for i in reversed(range(0,lastUnSuccessNumber)):
        lastAccessPerson = contract.functions.getOneUnSuccessAccessName(i).call()
        lastAccessTime = contract.functions.getOneUnSuccessAccessTime(i).call()
        allList.append({'person_name': lastAccessPerson, 'access_time': lastAccessTime})
    return jsonify(allList)

@app.route('/getLastUnSuccessAccess', methods=['GET'])
def getLastUnSuccessAccess():
    lastUnSuccessNumber = contract.functions.getUnSuccessAccessNumber().call()
    lastUnSuccessNumber = lastUnSuccessNumber - 1
    
    if (lastUnSuccessNumber < 0):
        return jsonify({'person_name': "", 'access_time': ""})
    
    lastAccessPerson = contract.functions.getOneUnSuccessAccessName(lastUnSuccessNumber).call()
    lastAccessTime = contract.functions.getOneUnSuccessAccessTime(lastUnSuccessNumber).call()
    return jsonify ({'person_name': lastAccessPerson, 'access_time': lastAccessTime})

# request body should be {"name": "accessName", "time": "accessTime"}
@app.route("/addNewUnSuccessAccess", methods=['POST'])
def addNewUnSuccessAccess():
    new_unsuccess = request.get_json()
    access_name = new_unsuccess['name']
    access_time = new_unsuccess['time']

    # update the contract with new person
    tx_hash = contract.functions.addUnSuccessPerson(access_name, access_time).transact()
    # wait until operation is done
    web3.eth.waitForTransactionReceipt(tx_hash)
    # after operation is done return okey
    return jsonify ({'ok': "okey"})

if __name__ == "__main__":
    app.run(debug=False)